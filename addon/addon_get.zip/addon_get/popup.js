
document.addEventListener('dsm', function (event) {
    var data = event.detail;
    console.log(data);
    chrome.storage.local.set({ data: data });
});

