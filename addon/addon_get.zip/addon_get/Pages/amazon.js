var designed = false;

chrome.storage.local.get("designed", function (items) {
  designed = items.designed;
});
var trending = false;
chrome.storage.local.get("trending", function (items) {
  trending = items.trending;
});
var el = document.getElementById("btnGetLink");
if (el) {
  el.addEventListener("click", function () {
    const getLink = $("#Link").val();
    $("#loadgif").slideDown();
    setTimeout(function () {
      $("#loadgif").slideUp();
    }, 2000);
    getUrl(getLink);
  });
}

async function getUrl(item) {
  try {
    let url_path = item;
    let vender = "";
    let tag = "";
    let vender_id = "";
    let description = "";
    let price = "";
    var category = null;
    if (url_path.indexOf("aliexpress") !== -1) {
      const product = await sendMessage({ type: "get", url: url_path });
      const dataMatchAli = product.match(/data:(.*?)}},\n/);
      const optionsNames = {};
      if (dataMatchAli) {
        const dataAli = parseJSONCustom(dataMatchAli[1] + "}}");
        title = dataAli.titleModule.subject;
        description = dataAli.pageModule.description;
        priceData = dataAli.priceModule.formatedActivityPrice;
        vender_id = dataAli.actionModule.productId;
        price = Price(priceData);
        vender = "aliexpress";
        let i = 1;
        const arr_option1 = [];
        const arr_option2 = [];
        let var_variants = [];
        const images = dataAli.imageModule.imagePathList;
        if (dataAli.skuModule.productSKUPropertyList) {
          for (const element of dataAli.skuModule.productSKUPropertyList) {
            optionsNames[`option${i}_name`] = element.skuPropertyName;
            i++;
          }
          const option_arr = {};
          let m = 0;
          for (const item of dataAli.skuModule.productSKUPropertyList) {
            const varr = [];
            for (const size of item.skuPropertyValues) {
              if (
                size.skuPropertyImagePath ||
                size.skuPropertyImagePathskuPropertyImageSummPath
              ) {
                const itemv = {
                  id: size.propertyValueId,
                  name: size.skuPropertyValueTips,
                  image:
                    size.skuPropertyImagePath !== undefined
                      ? size.skuPropertyImagePath
                      : size.skuPropertyImagePathskuPropertyImageSummPath,
                };
                varr.push(itemv);
              } else {
                const itemv = {
                  id: size.propertyValueId,
                  name: size.skuPropertyValueTips,
                };
                varr.push(itemv);
              }
            }
            m++;
            option_arr[`arr_option${m}`] = varr;
          }
          const variants = dataAli.skuModule.skuPriceList;
          let sku = 1;
          for (const item of variants) {
            const variant = {
              shipping_cost: 0,
              quantity: 9999,
              origin_price: true,
              price: Number(item.skuVal.actSkuCalPrice),
            };
            if (dataAli.skuModule.productSKUPropertyList.length === 1) {
              const variant1 = {
                ...variant,
                sku: `Aliexpress_${sku}`,
                option1: ChecOption(item.skuPropIds, option_arr.arr_option1),
                var_images: CheckImg(item.skuPropIds, option_arr.arr_option1),
              };
              sku++;
              var_variants.push(variant1);
            } else if (dataAli.skuModule.productSKUPropertyList.length === 2) {
              const variant1 = {
                ...variant,
                sku: `Aliexpress_${sku}`,
                option1: ChecOption1(item.skuPropIds, option_arr.arr_option1),
                option2: ChecOption2(item.skuPropIds, option_arr.arr_option2),
                var_images: CheckImg1(
                  item.skuPropIds,
                  option_arr.arr_option1,
                  option_arr.arr_option2
                ),
              };
              sku++;
              var_variants.push(variant1);
            } else if (dataAli.skuModule.productSKUPropertyList.length > 2) {
              const variant1 = {
                ...variant,
                sku: `Aliexpress_${sku}`,
                option1: ChecOption1(item.skuPropIds, option_arr.arr_option1),
                option2: ChecOption23(item.skuPropIds, option_arr.arr_option2),
                option3: ChecOption3(item.skuPropIds, option_arr.arr_option3),
                var_images: CheckImg1(
                  item.skuPropIds,
                  option_arr.arr_option1,
                  option_arr.arr_option2
                ),
              };
              sku++;
              var_variants.push(variant1);
            }
          }
        } else {
          var_variants = [];
        }
        const data = {
          ...optionsNames,
          title: title,
          price: Number(price),
          variants: var_variants,
          images: [images[0]],
          option1_picture: 0,
          quantity: 999999,
          shipping_cost: 0,
          description: description,
          vender: vender,
          slug: Slug(title),
          vender_url: url_path,
          vender_id: vender_id,
          tags: tag,
          google_category: getGoogleCategory(title),
          categories: category,
          gender: "All",
          designed: -1,
          trending: 0,
          feedback: null,
          rank: null,
          specifics: null,
          delivery_date_min: 5,
          delivery_date_max: 20,
          location: "USA",
          shipping_service_name: "Economy Shipping",
        };
        await GetValueData(data);
      } else {
        sendNull();
        return;
      }
    } else if (url_path.indexOf("amazon") !== -1) {
      vender = "amazon";
      vender_id = url_path.match(/dp\/(.*?)\//)[1];
      const product = await sendMessage({ type: "get", url: url_path });
      if (Object.keys(product).length == 0) {
        sendNull();
        return;
      }

      const matchImgVariant = product.match(
        /var obj = jQuery\.parseJSON\('(.*?)'\);\n/
      );
      const jsonImgMap = parseJSONCustom(matchImgVariant[1]);
      if (matchImgVariant) {
        const matchDimensionAsin = product.match(
          /"dimensionToAsinMap" : (.*?),\n/
        );
        const matchDimensionValue = product.match(
          /"dimensionValuesData" : (.*?),\n/
        );
        const matchVariantsDisplayLabels = product.match(
          /"variationDisplayLabels" : (.*?),\n/
        );
        const matchDimensions = product.match(/"dimensions" : (.*?),\n/);
        const { title, colorToAsin, colorImages } = jsonImgMap;
        const optionsNames = {};
        let variants = [];
        const price = $(product)
          .find("#price .a-size-medium.a-color-price")
          .text()
          .replace("$", "");
        const image = $(product).find("#altImages ul li img");
        const images = [];
        $(image).each(function (_, item) {
          const Item = $(item).attr("src");
          images.push(Item);
        });
        if (matchDimensionAsin !== null) {
          const jsonDimensionAsin = parseJSONCustom(matchDimensionAsin[1]);
          const jsonDimensionValue = parseJSONCustom(matchDimensionValue[1]);
          const jsonVariantDisplayLabels = parseJSONCustom(
            matchVariantsDisplayLabels[1]
          );
          const jsonDimension = parseJSONCustom(matchDimensions[1]);

          let nKey = 1;
          for (const key of jsonDimension) {
            optionsNames[`option${nKey}_name`] = jsonVariantDisplayLabels[key];
            nKey += 1;
          }
          const variantMaps = [];
          for (const dAKey in jsonDimensionAsin) {
            const keyArr = dAKey.split("_");
            const asin = jsonDimensionAsin[dAKey];
            let key = 0;
            const options = {};
            for (const kMap of keyArr) {
              options[`option${key + 1}`] =
                jsonDimensionValue[key][Number(kMap)];
              (options.price = (parseFloat(price) - 1).toFixed(2)),
                (options.asin = asin);
              options.origin_price = true;
              key += 1;
            }

            variantMaps.push({
              ...options,
            });
          }

          const variantsWithImages = [];

          for (const colorKey in colorToAsin) {
            const { asin } = colorToAsin[colorKey];
            const images = colorImages[colorKey].map(
              (img) => img.hiRes || img.large
            );
            for (const variantItem of variantMaps) {
              if (variantItem.asin === asin) {
                variantsWithImages.push({
                  ...variantItem,
                  var_images: images[0],
                });
              }
            }
          }
          let sku = 1;
          for (const variantImg of variantsWithImages) {
            const {
              option1,
              option2,
              option3,
              option4,
              var_images,
            } = variantImg;
            for (const variantItem of variantMaps) {
              if (
                variantItem.option1 == option1 &&
                variantItem.option2 == option2
              ) {
                delete variantItem.asin;
                variants.push({
                  ...variantItem,
                  sku: `Amazon_${sku}`,
                  var_images,
                });
                sku++;
              }
            }
          }
        } else {
          variants = [];
        }
        const data = {
          ...optionsNames,
          title: title,
          price: Number(price),
          variants: variants,
          images: variants.length ? variants[0].var_images : images,
          option1_picture: 0,
          quantity: 999999,
          shipping_cost: 0,
          description:
            $(product).find("#productDescription").html() !== undefined
              ? $(product).find("#productDescription").html().trim()
              : description,
          vender: vender,
          slug: Slug(title),
          vender_url: url_path,
          vender_id: vender_id,
          tags: tag,
          google_category: getGoogleCategory(title),
          categories: category,
          gender: "All",
          designed: -1,
          trending: 0,
          feedback: null,
          rank: null,
          specifics: null,
          delivery_date_min: 5,
          delivery_date_max: 20,
          location: "USA",
          shipping_service_name: "Economy Shipping",
        };
        await GetValueData(data);
      } else {
        sendNull();
        return;
      }
    }
  } catch (e) {
    console.error(e);
  }
}

function GetValueData(item) {
  $("#form").slideDown();
  $("#Title").val(item.title);
  $("#Slug").val(item.slug);
  $("#Category").val(item.category);
  $("#Tags").val(item.Tags);
  $("#Vender").val(item.vender);
  $("#Vender_id").val(item.vender_id);
  $("#Vender_url").val(item.vender_url);
  $("textarea#content").val(item.description);
  $("#Price").val(item.price);
  $("#Images").val(item.images);
  $("#option1_name").val(item.option1_name);
  $("#option2_name").val(item.option2_name);
  $("#option3_name").val(item.option3_name);
  $("#option1_picture").val(item.option1_picture);
  $("#Delivery_date_min").val(item.delivery_date_min);
  $("#Delivery_date_max").val(item.delivery_date_max);
  $("#content-click").click();
  const data = item.variants;
  if (data.length) {
    for (let i = 0; i <= data.length - 1; i++) {
      $("#Tb_variants").append(
        `
        <tr id="tr_${i}">
        <td> <input type="text" class="form-control"  value=" ${
          data[i].sku
        }" disabled  style="border: none; background:none">
          </td>
        <td>
            <input type="text" class="form-control"  value="${
              data[i].option1
            }" placeholder="Enter Option1">
        </td>
        <td>
            <input type="text" class="form-control"  value="${
              typeof data[i].option2 !== "undefined" ? data[i].option2 : ""
            }" placeholder="Enter Option2">
        </td>
        <td>
              <input type="text" class="form-control"  value="${
                typeof data[i].option3 !== "undefined" ? data[i].option3 : ""
              }" placeholder="Enter Option3">
        </td>
        <td>
            <input type="text" class="form-control"  value="$ ${
              data[i].price
            }" placeholder="Enter Price">
        </td>
        <td>
              <input type="text" class="form-control"  value="${
                data[i].var_images
              }" placeholder="Enter Images">
        </td>
        <td>  <a class="btn btn-app" onclick="Remove(this)">
                <i class="fa fa-trash-o"></i> Remove
              </a>
         </td>
       </tr>
      `
      );
    }
  }
}

function timeout(ms = 10000) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}
