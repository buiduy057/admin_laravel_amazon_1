let data;
chrome.storage.local.get("data", function (item) {
  data = item;
  getMessage(data);
});
function getMessage(data) {
  if (window.location.href.indexOf("https://www.ebay.com/") > -1) {
    console.log("ok");
    console.log(data);
    // chrome.storage.local.clear();
  }
}
