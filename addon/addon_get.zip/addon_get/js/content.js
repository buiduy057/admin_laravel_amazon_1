function Price(item) {
  let price = 0;
  if (item.indexOf("-") !== -1) {
    price = Number(item.slice(item.indexOf("$") + 1, item.indexOf("-") - 1));
  } else {
    price = Number(item.slice(item.indexOf("$") + 1, item.length));
  }
  return price;
}

function CheckImg1(id, arr1, arr2, arr3) {
  const img = [];
  if (arr1[0].image) {
    const id01 = id.slice(0, id.indexOf(","));
    for (let i = 0; i <= arr1.length - 1; i++) {
      if (Number(id01) === arr1[i].id) {
        img.push(arr1[i].image);
        return img;
      }
    }
  } else if (arr2[0].image) {
    const id02 = id.slice(id.indexOf(",") + 1, id.length);
    for (let i = 0; i <= arr2.length - 1; i++) {
      if (Number(id02) === arr2[i].id) {
        img.push(arr1[i].image);
        return img;
      }
    }
  } else if (arr3[0].image) {
    const id01 = id.slice(0, id.indexOf(","));
    for (let i = 0; i <= arr1.length - 1; i++) {
      if (Number(id01) === arr1[i].id) {
        img.push(arr1[i].image);
        return img;
      }
    }
  } else {
    return img;
  }
}
function CheckImg(id, arr) {
  const img = [];
  for (let i = 0; i <= arr.length - 1; i++) {
    if (Number(id) === arr[i].id) {
      img.push(arr[i].image);
      return img;
    }
  }
}
function ChecOption1(id, arr1) {
  const id01 = id.slice(0, id.indexOf(","));
  for (let i = 0; i <= arr1.length - 1; i++) {
    if (Number(id01) === arr1[i].id) {
      const ItemChat =
        arr1[i].name.charAt(0).toUpperCase() + arr1[i].name.slice(1);
      return ItemChat;
    }
  }
}
function ChecOption23(id, arr1) {
  const id01 = id.slice(id.indexOf(",") + 1, id.lastIndexOf(","));
  for (let i = 0; i <= arr1.length - 1; i++) {
    if (Number(id01) === arr1[i].id) {
      const ItemChat =
        arr1[i].name.charAt(0).toUpperCase() + arr1[i].name.slice(1);
      return ItemChat;
    }
  }
}
function ChecOption3(id, arr1) {
  const id01 = id.slice(id.lastIndexOf(",") + 1, id.length);
  for (let i = 0; i <= arr1.length - 1; i++) {
    if (Number(id01) === arr1[i].id) {
      const ItemChat =
        arr1[i].name.charAt(0).toUpperCase() + arr1[i].name.slice(1);
      return ItemChat;
    }
  }
}
function ChecOption(id, arr) {
  for (let i = 0; i <= arr.length - 1; i++) {
    if (Number(id) === arr[i].id) {
      return arr[i].name;
    }
  }
}
function ChecOption2(id, arr2) {
  const id02 = id.slice(id.indexOf(",") + 1, id.length);
  for (let i = 0; i <= arr2.length - 1; i++) {
    if (Number(id02) === arr2[i].id) {
      return arr2[i].name;
    }
  }
}
function sendNull() {
  $("#alert_wanning").append(
    `
      <div class="alert alert-warning alert-dismissible">
        <h4><i class="icon fa fa-warning"></i> Alert!</h4>
          Re-enter the link.
      </div> 
      `
  );
  setTimeout(function () {
    $("#alert_wanning").slideUp();
  }, 3000);
}
function sendMessage(action) {
  return new Promise((resolve) => {
    chrome.runtime.sendMessage(action, function (response) {
      resolve(response);
    });
  });
}
function Slug(item) {
  slug = item.toLowerCase();
  slug = slug.replace(/á|à|ả|ạ|ã|ă|ắ|ằ|ẳ|ẵ|ặ|â|ấ|ầ|ẩ|ẫ|ậ/gi, "a");
  slug = slug.replace(/é|è|ẻ|ẽ|ẹ|ê|ế|ề|ể|ễ|ệ/gi, "e");
  slug = slug.replace(/i|í|ì|ỉ|ĩ|ị/gi, "i");
  slug = slug.replace(/ó|ò|ỏ|õ|ọ|ô|ố|ồ|ổ|ỗ|ộ|ơ|ớ|ờ|ở|ỡ|ợ/gi, "o");
  slug = slug.replace(/ú|ù|ủ|ũ|ụ|ư|ứ|ừ|ử|ữ|ự/gi, "u");
  slug = slug.replace(/ý|ỳ|ỷ|ỹ|ỵ/gi, "y");
  slug = slug.replace(/đ/gi, "d");
  slug = slug.replace(
    /\`|\~|\!|\@|\#|\||\$|\%|\^|\&|\*|\(|\)|\+|\=|\,|\.|\/|\?|\>|\<|\'|\"|\:|\;|_/gi,
    ""
  );
  slug = slug.replace(/ /gi, "-");
  slug = slug.replace(/\-\-\-\-\-/gi, "-");
  slug = slug.replace(/\-\-\-\-/gi, "-");
  slug = slug.replace(/\-\-\-/gi, "-");
  slug = slug.replace(/\-\-/gi, "-");
  slug = "@" + slug + "@";
  slug = slug.replace(/\@\-|\-\@|\@/gi, "");
  return slug;
}
