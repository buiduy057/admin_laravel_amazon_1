function checkLocation(path) {
  return window.location.href.indexOf(path) > -1;
}

function timeOut(ms = 5000) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}
function requestToServer(item) {
  const url = "https://api.customray.com/admin/product/create-tool";
  const formData = new FormData();
  formData.append("item", JSON.stringify(item));

  return new Promise((resolve, reject) => {
    fetch(url, { method: "POST", body: formData })
      .then((res) => res.json())
      .then(resolve)
      .catch(reject);
  });
}

function request(url, method = "GET", data = {}) {
  return new Promise((resolve, reject) => {
    const options = {
      method,
    };
    if (method === "POST") {
      const formData = new FormData();
      for (const key in data) {
        formData.append(key, data[key]);
      }

      options.body = formData;
    }

    fetch(url, options)
      .then((response) => response.json())
      .then(resolve)
      .catch(reject);
  });
}

function requestText(url, method = "GET", data = {}) {
  return new Promise((resolve, reject) => {
    const options = {
      method,
    };
    if (method === "POST") {
      const formData = new FormData();
      for (const key in data) {
        formData.append(key, data[key]);
      }

      options.body = formData;
    }

    fetch(url, options)
      .then((response) => response.text())
      .then(resolve)
      .catch(reject);
  });
}

function send(item, vender) {
  // console.log(item);
  $.ajax({
    url: "https://api.customray.com/admin/product/create-tool",
    type: "post",
    dataType: "text",
    data: {
      item: JSON.stringify(item),
    },

    vender: vender,
    success: function (data) {
      console.log(data);
      // console.log(this.next);
      // window.close();
    },
    error: function (request, error) {
      console.log(data);

      // var url_string  = window.location.href;
      // window.location.href = url_string;
      // window.close();
    },
  });
}

function randomStr(length) {
  var result = "";
  var characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
  var charactersLength = characters.length;
  for (var i = 0; i < length; i++) {
    result += characters.charAt(Math.floor(Math.random() * charactersLength));
  }
  return result;
}

function getCategoryFromStorage() {
  return new Promise((resolve, reject) => {
    chrome.storage.local.get("category", function (result) {
      if (result.category) {
        const category = result.category.toUpperCase();
        const jsonCategory = category.split(", ");
        resolve(jsonCategory);
      } else {
        resolve([]);
      }
    });
  });
}
function makeid(length) {
  var result = "";
  var characters =
    "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
  var charactersLength = characters.length;
  for (var i = 0; i < length; i++) {
    result += characters.charAt(Math.floor(Math.random() * charactersLength));
  }
  return result;
}
function getCategoryFromString(string) {
  const category = string.toUpperCase();
  const jsonCategory = category.split(", ");
  return jsonCategory;
}

function getGoogleCategory(payload = "") {
  const str = payload.toLowerCase();

  if (str == "t-shirt" || includesOfString(str, "shirt")) {
    return "Apparel & Accessories > Clothing > Shirts & Tops";
  }

  if (includesOfString(str, "ring")) {
    return "Apparel & Accessories > Jewelry > Rings";
  }

  if (
    includesOfString(str, "anthony") ||
    includesOfString(str, "m.a-s.k") ||
    includesOfString(str, "carbon") ||
    includesOfString(str, "layers") ||
    includesOfString(str, "bandana") ||
    includesOfString(str, "mask")
  ) {
    return "Apparel & Accessories > Costumes & Accessories > Masks";
  }

  if (includesOfString(str, "mugs")) {
    return "Home & Garden > Kitchen & Dining > Tableware > Drinkware > Mugs";
  }

  if (includesOfString(str, "socks")) {
    return "Apparel & Accessories > Clothing > Underwear & Socks > Socks";
  }

  if (includesOfString(str, "phone case")) {
    return "Electronics > Communications > Telephony > Mobile Phone Accessories > Mobile Phone Cases";
  }

  if (includesOfString(str, "canvas")) {
    return "Arts & Entertainment > Hobbies & Creative Arts > Arts & Crafts > Art & Crafting Materials > Textiles > Crafting Canvas";
  }

  if (includesOfString(str, "bag")) {
    return "Luggage & Bags";
  }

  if (includesOfString(str, "backpack")) {
    return "Luggage & Bags > Backpacks";
  }

  if (includesOfString(str, "totes")) {
    return "Luggage & Bags > Shopping Totes";
  }

  if (includesOfString(str, "pillow cover")) {
    return "Home & Garden > Linens & Bedding > Bedding > Pillows";
  }

  if (includesOfString(str, "flag")) {
    return "Home & Garden > Decor > Flag & Windsock Accessories";
  }

  if (includesOfString(str, "charm") || includesOfString(str, "ornament")) {
    return "Apparel & Accessories > Jewelry > Charms & Pendants";
  }

  if (includesOfString(str, "door mat")) {
    return "Home & Garden > Decor > Door Mats";
  }

  if (includesOfString(str, "watch")) {
    return "Apparel & Accessories > Jewelry > Watches";
  }

  if (includesOfString(str, "bangle")) {
    return "Apparel & Accessories > Jewelry";
  }

  if (includesOfString(str, "shorts")) {
    return "Apparel & Accessories > Clothing > Shorts";
  }

  if (includesOfString(str, "hoodie")) {
    return "Apparel & Accessories > Clothing > Outerwear";
  }

  if (includesOfString(str, "dress")) {
    return "Apparel & Accessories > Clothing > Dresses";
  }

  if (includesOfString(str, "tumbler")) {
    return "Home & Garden > Kitchen & Dining > Tableware > Drinkware > Tumblers";
  }

  if (includesOfString(str, "blanket")) {
    return "Home & Garden > Linens & Bedding > Bedding > Blanket";
  }

  if (includesOfString(str, "quilt")) {
    return "Home & Garden > Linens & Bedding > Bedding > Quilts & Comforters";
  }

  if (includesOfString(str, "clothes") || includesOfString(str, "rugs")) {
    return "Apparel & Accessories > Clothing > Shirts & Tops";
  }

  if (includesOfString(str, "leggings")) {
    return "Apparel & Accessories > Clothing";
  }

  if (
    includesOfString(str, "sneaker") ||
    includesOfString(str, "shoes") ||
    includesOfString(str, "boots")
  ) {
    return "Apparel & Accessories > Shoes";
  }

  if (
    includesOfString(str, "sneaker") ||
    includesOfString(str, "shoes") ||
    includesOfString(str, "boots")
  ) {
    return "Apparel & Accessories > Shoes";
  }

  if (includesOfString(str, "bedding set")) {
    return "Apparel & Accessories > Shoes";
  }

  if (includesOfString(str, "tablecloth")) {
    return "Home & Garden > Kitchen & Dining > Tableware > Tablecloth Clips & Weights";
  }

  if (
    includesOfString(str, "seat cover") ||
    includesOfString(str, "car seat")
  ) {
    return "Sporting Goods > Outdoor Recreation > Cycling > Bicycle Accessories > Bicycle Saddle Pads & Seat Covers";
  }

  if (
    includesOfString(str, "seat cover") ||
    includesOfString(str, "car seat")
  ) {
    return "Sporting Goods > Outdoor Recreation > Cycling > Bicycle Accessories > Bicycle Saddle Pads & Seat Covers";
  }

  if (includesOfString(str, "shades")) {
    return "Home & Garden > Lawn & Garden > Outdoor Living > Outdoor Umbrellas & Sunshades";
  }

  return "Apparel & Accessories";
}

function includesOfString(string, needed) {
  return string.indexOf(needed) > -1;
}

function parseJSONCustom(string) {
  string = string
    .replace(/\\n/g, "\\n")
    .replace(/\\'/g, "'")
    .replace(/\\'/g, "\\'")
    .replace(/\\"/g, '\\"')
    .replace(/\\&/g, "\\&")
    .replace(/\\r/g, "\\r")
    .replace(/\\t/g, "\\t")
    .replace(/\\b/g, "\\b")
    .replace(/\\f/g, "\\f");
  string = string.replace(/[\u0000-\u0019]+/g, "");
  return JSON.parse(string);
}

function filterCategoryVA(titleitem) {
  console.log(titleitem);
  let ggcate = "Apparel & Accessories > Clothing > Shirts & Tops";
  if (
    titleitem.indexOf("Anthony") != -1 ||
    titleitem.indexOf("M.a-s.k") != -1 ||
    titleitem.indexOf("Carbon") != -1 ||
    titleitem.indexOf("Layers") != -1 ||
    titleitem.indexOf("Bandana") != -1 ||
    titleitem.indexOf("Mask") != -1
  ) {
    ggcate = "Apparel & Accessories > Costumes & Accessories > Masks";
  } else if (
    titleitem.indexOf("MUGS") != -1 ||
    titleitem.indexOf("Mugs") != -1
  ) {
    ggcate = "Home & Garden > Kitchen & Dining > Tableware > Drinkware > Mugs";
  } else if (
    titleitem.indexOf("SOCKS") != -1 ||
    titleitem.indexOf("Socks") != -1
  ) {
    ggcate = "Apparel & Accessories > Clothing > Underwear & Socks > Socks";
  } else if (
    titleitem.indexOf("PHONE CASE") != -1 ||
    titleitem.indexOf("Phone Case") != -1
  ) {
    ggcate =
      "Electronics > Communications > Telephony > Mobile Phone Accessories > Mobile Phone Cases";
  } else if (
    titleitem.indexOf("CANVAS") != -1 ||
    titleitem.indexOf("Canvas") != -1
  ) {
    ggcate =
      "Arts & Entertainment > Hobbies & Creative Arts > Arts & Crafts > Art & Crafting Materials > Textiles > Crafting Canvas";
  } else if (titleitem.indexOf("BAG") != -1 || titleitem.indexOf("Bag") != -1) {
    ggcate = "Luggage & Bags";
  } else if (
    titleitem.indexOf("BACKPACK") != -1 ||
    titleitem.indexOf("Backpack") != -1
  ) {
    ggcate = "Luggage & Bags > Backpacks";
  } else if (
    titleitem.indexOf("TOTES") != -1 ||
    titleitem.indexOf("Totes") != -1 ||
    titleitem.indexOf("TOTE") != -1
  ) {
    ggcate = "Luggage & Bags > Shopping Totes";
  } else if (
    titleitem.indexOf("PILLOW COVER") != -1 ||
    titleitem.indexOf("Pillow Cover") != -1
  ) {
    ggcate = "Home & Garden > Linens & Bedding > Bedding > Pillows";
  } else if (
    titleitem.indexOf("Flag") != -1 ||
    titleitem.indexOf("FLAG") != -1
  ) {
    ggcate = "Home & Garden > Linens & Bedding > Bedding > Pillows";
  } else if (
    titleitem.indexOf("BACK CAR") != -1 ||
    titleitem.indexOf("Back Car") != -1
  ) {
    ggcate = "Apparel & Accessories";
  } else if (
    titleitem.indexOf("CHARM") != -1 ||
    titleitem.indexOf("Charm") != -1 ||
    titleitem.indexOf("Ornament") != -1
  ) {
    ggcate = "Apparel & Accessories > Jewelry > Charms & Pendants";
  } else if (
    titleitem.indexOf("DOOR MAT") != -1 ||
    titleitem.indexOf("Door Mat") != -1
  ) {
    ggcate = "Home & Garden > Decor > Door Mats";
  } else if (
    titleitem.indexOf("WATCH") != -1 ||
    titleitem.indexOf("Watch") != -1
  ) {
    ggcate = "Apparel & Accessories > Jewelry > Watches";
  } else if (
    titleitem.indexOf("BANGLE") != -1 ||
    titleitem.indexOf("Bangle") != -1
  ) {
    ggcate = "Apparel & Accessories > Jewelry";
  } else if (titleitem.indexOf("Shorts") != -1) {
    ggcate = "Apparel & Accessories > Clothing > Shorts";
  } else if (titleitem.indexOf("Hoodie") != -1) {
    ggcate = "Apparel & Accessories > Clothing > Outerwear";
  } else if (titleitem.indexOf("Dress") != -1) {
    ggcate = "Apparel & Accessories > Clothing > Dresses";
  } else if (titleitem.indexOf("Quilt") != -1) {
    ggcate = "Home & Garden > Linens & Bedding > Bedding > Quilts & Comforters";
  } else if (titleitem.indexOf("Blanket") != -1) {
    ggcate = "Home & Garden > Linens & Bedding > Bedding > Blanket";
  } else if (titleitem.indexOf("Tumbler") != -1) {
    ggcate =
      "Home & Garden > Kitchen & Dining > Tableware > Drinkware > Tumblers";
  } else if (titleitem.indexOf("DRESS") != -1) {
    ggcate = "Apparel & Accessories > Clothing > Dresses";
  } else if (titleitem.indexOf("Clothes") != -1) {
    ggcate = "Apparel & Accessories > Clothing > Shirts & Tops";
  } else if (titleitem.indexOf("LEGGINGS") != -1) {
    ggcate = "Apparel & Accessories > Clothing";
  } else if (
    titleitem.indexOf("Sneaker") != -1 ||
    titleitem.indexOf("Shoes") != -1 ||
    titleitem.indexOf("SHOES") != -1 ||
    titleitem.indexOf("BOOTS") != -1 ||
    titleitem.indexOf("SNEAKER") != -1 ||
    titleitem.indexOf("Boots") != -1
  ) {
    ggcate = "Apparel & Accessories > Shoes";
  } else if (
    titleitem.indexOf("Shirt") != -1 ||
    titleitem.indexOf("T-Shirt") != -1
  ) {
    ggcate = "Apparel & Accessories > Clothing > Shirts & Tops";
  } else if (
    titleitem.indexOf("Rugs") != -1 ||
    titleitem.indexOf("Rug") != -1
  ) {
    ggcate = "Apparel & Accessories > Clothing > Shirts & Tops";
  } else if (
    titleitem.indexOf("Bedding Set") != -1 ||
    titleitem.indexOf("Bedding") != -1
  ) {
    ggcate = "Home & Garden > Linens & Bedding > Bedding > Pillows";
  } else if (titleitem.indexOf("Tablecloth") != -1) {
    ggcate =
      "Home & Garden > Kitchen & Dining > Tableware > Tablecloth Clips & Weights";
  } else if (
    titleitem.indexOf("Seat Cover") != -1 ||
    titleitem.indexOf("Seat Covers") != -1 ||
    titleitem.indexOf("CAR SEAT") != -1
  ) {
    ggcate =
      "Sporting Goods > Outdoor Recreation > Cycling > Bicycle Accessories > Bicycle Saddle Pads & Seat Covers";
  } else if (titleitem.indexOf("Pillow Cover") != -1) {
    ggcate = "Home & Garden > Linens & Bedding > Bedding > Pillows";
  } else if (titleitem.indexOf("Shades") != -1) {
    ggcate =
      "Home & Garden > Lawn & Garden > Outdoor Living > Outdoor Umbrellas & Sunshades";
  } else {
    return "Apparel & Accessories > Clothing > Shirts & Tops";
  }
  console.log(ggcate);
  return ggcate;
}
