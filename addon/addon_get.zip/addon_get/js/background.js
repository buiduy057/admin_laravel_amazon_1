chrome.runtime.onMessage.addListener(function (action, sender, sendResponse) {
  if (action.type == "get") {
    request(action.url)
      .then((body) => sendResponse(body))
      .catch((e) => sendResponse(e));
  }

  return true;
});

function request(url) {
  return new Promise(async (resolve, reject) => {
    try {
      const request = await fetch(url);
      const response = request.text();
      resolve(response);
    } catch (e) {
      reject(e);
    }
  });
}
